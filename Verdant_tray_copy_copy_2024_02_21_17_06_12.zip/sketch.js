let img0;
let img1;
let img2;
let img3;
let img4;
let img5;
let img6;
let mp4;
var bgm;
var tombImages;
var RandomImg;
var rd;

function preload(){
  bgm= loadSound('bg.mp3');
  soil= loadSound('soil.mp3');
  s1= loadSound('01.mp3');
  img0 =loadImage('0.png');
  img1 = loadImage('background1.png');
  img2 = loadImage('tomb1.png');
  img3 = loadImage('tomb2.png');
  img4 = loadImage('tomb3.png');
  img5 = loadImage('tomb4.png');
  img6 = loadImage('tomb5.png');
  img7 = loadImage('tomb6.png');
  img8 = loadImage('death.png');
  block =loadImage('block.png');
  mp4 = createVideo("death.mp4");
  
   tombImages = [
		"tomb2.png",
        "tomb3.png",
        "tomb4.png",
        "tomb5.png",
        "tomb6.png",
    ];
  	
}

function setup() {
  bgm.loop();
  createCanvas(windowWidth, windowHeight);
  background(img1);
}

function draw() {
  image(img0,50,30,300,150);
}

function mousePressed(){
  var pos = floor(random(tombImages.length));
  RandomImg = loadImage(tombImages[pos]);
    rd= random(0, 500);
    if (rd >= 455) {
    image(img8,90,100,620,700);
    s1.play();
    setTimeout(reset,700);
    }   
}

function reset(){
  background(img1);
}

function mouseClicked(){

  image(RandomImg,mouseX, mouseY,150,150);
  soil.play();
  
}
